import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {ApiAuthentication} from '../../../providers/api-authentication'
import { Ionic2Rating } from 'ionic2-rating';
import { DetailsPage } from '../../details/details';

/*
  Generated class for the Category9 page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-category-9',
  templateUrl: 'category-9.html',
  providers: [ApiAuthentication]

})
export class Category9Page {
  private rate = 2.5;
  public api: any;
  detailsPage = DetailsPage;

  constructor(public navCtrl: NavController, public navParams: NavParams, public apiAuthentication: ApiAuthentication) {
  	this.loadRecipes();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Category9Page');
  }

  loadRecipes(){
    this.apiAuthentication.loadCategory9()
    .then(data => {
      this.api = data;
    });
  } 
}
