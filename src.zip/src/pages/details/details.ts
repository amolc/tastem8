import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ApiAuthentication } from '../../providers/api-authentication'
import { Ionic2Rating } from 'ionic2-rating';
import { Platform } from 'ionic-angular';
import { InAppBrowser, Geolocation } from 'ionic-native';

/*
  Generated class for the Details page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/

declare var google;

@Component({
  selector: 'page-details',
  templateUrl: 'details.html',
  providers: [ApiAuthentication]

})
export class DetailsPage {
  private rate = 2.5;
  public api: any;
  public cordova: any;
  visible = false;
  public id;
  public counter : number = 0;
  
  constructor(public navCtrl: NavController, private navParams: NavParams, public apiAuthentication: ApiAuthentication, private platform: Platform) {
    this.loadRecipes();
    // this.id = navParams.get('id');
  }

  toggle() {
    this.visible = !this.visible;

    if (!this.visible) {
      this.counter -= 1;
    } else {
      this.counter += 1
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DetailsPage');
    this.loadMap();
  }

  launch(url) {
    this.platform.ready().then(() => {
        // cordova.InAppBrowser.open(url, "_system", "location=true");
    });
  }

  loadRecipes(){
    this.id = "test";
    this.apiAuthentication.loadDetails()
    .then(data => {
      this.api = data;
    });
  } 

  @ViewChild('map') mapElement: ElementRef;
  map: any;
 
  loadMap(){
 
    Geolocation.getCurrentPosition().then((position) => {
 
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
 
      let mapOptions = {
        center: latLng,
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
 
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
 
    }, (err) => {
      console.log(err);
    });
 
  }

  submit() {

  }

  // addMarker(){
   
  //   let marker = new google.maps.Marker({
  //     map: this.map,
  //     animation: google.maps.Animation.DROP,
  //     position: this.map.getCenter()
  //   });
   
  //   let content = "<h4>You are here!</h4>";          
   
  //   this.addInfoWindow(marker, content);
   
  // }

  // addInfoWindow(marker, content){
   
  //   let infoWindow = new google.maps.InfoWindow({
  //     content: content
  //   });
   
  //   google.maps.event.addListener(marker, 'click', () => {
  //     infoWindow.open(this.map, marker);
  //   });
  // }
}
