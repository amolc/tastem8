export class Config {
  public static FIREBASE_CONFIG = {
    apiKey: "AIzaSyAxuA8_qyukTjYJKLkiraglG2RRDAbtn_8",
    authDomain: "tastem8-a10a3.firebaseapp.com",
    databaseURL: "https://tastem8-a10a3.firebaseio.com",
    storageBucket: "tastem8-a10a3.appspot.com",
  };
  public static WEB_CLIENT_ID = '138755212334-m2mecrn1q07sat14jvr3ts2krpt414p3.apps.googleusercontent.com';
}
